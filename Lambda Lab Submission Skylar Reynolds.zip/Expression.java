
public interface Expression {
// i cant even pretend to say this file is well organized...its one line
	public Expression deepCopy();
}
