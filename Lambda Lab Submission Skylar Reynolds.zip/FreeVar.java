
public class FreeVar extends Variable {

    public FreeVar(String name){
        super(name);
    }

    public void setName(String newName) {
        //do nothing
    }
}
