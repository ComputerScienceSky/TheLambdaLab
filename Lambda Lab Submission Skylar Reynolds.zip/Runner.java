public class Runner{
	public static Expression run(Expression exp) {
		return exp;
	}
}