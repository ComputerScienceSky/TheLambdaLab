
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lexer {

	/*
	 * A lexer (or "tokenizer") converts an input into tokens that
	 * eventually need to be interpreted.
	 * 
	 * Given the input 
	 *    (\bat  .bat flies)cat  λg.joy! )
	 * you should output the ArrayList of strings
	 *    [(, \, bat, ., bat, flies, ), cat, \, g, ., joy!, )]
	 *
	 */
	public ArrayList<String> tokenize(String input) {
		ArrayList<String> tokens = new ArrayList<String>();
		ArrayList<String> varName = new ArrayList<String>();

		for(int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);

			if (Character.isWhitespace(c)) {
				if(varName.size() > 0) {
					addVarIfAppropriate(tokens, varName);
					varName = new ArrayList<String>();
				}
			} else if(c == '(' || c == ')' || c == ';' || c == '\\' || c == 'λ' || c == '.' || c == '=') {
				if(c == ';') {
					break;
				}
				addVarIfAppropriate(tokens, varName);
				varName = new ArrayList<String>();
				tokens.add(Character.toString(c));
			} else {
				varName.add(Character.toString(c));
			}
		}
		addVarIfAppropriate(tokens, varName);

		System.out.println(tokens);
		return tokens;
	}

	public void addVarIfAppropriate(ArrayList<String> tokens, ArrayList<String> varName){
		if (varName.size() > 0) {
			String varFinal = "";
			for(int i = 0; i < varName.size(); i++) {
				varFinal += varName.get(i);
			}
			tokens.add(varFinal);
		}
	}

	//	public static void testLexer() {
	//	    Lexer lexer = new Lexer();
	//
	//	    String input1 = "(   (\\bat  .bat flies)cat   );     comment";
	//	    ArrayList<String> tokens1 = lexer.tokenize(input1);
	//	    System.out.println("Input: " + input1);
	//	    System.out.println("Tokens: " + tokens1);
	//
	//	    String input2 = "((cu (a λboo.a boo) )) day";
	//	    ArrayList<String> tokens2 = lexer.tokenize(input2);
	//	    System.out.println("Input: " + input2);
	//	    System.out.println("Tokens: " + tokens2);
	//
	//	    String input3 = "\\bat .bat (flies)cat = λg.joy!";
	//	    ArrayList<String> tokens3 = lexer.tokenize(input3);
	//	    System.out.println("Input: " + input3);
	//	    System.out.println("Tokens: " + tokens3);
	//	}
	//
	//	public static void main(String[] args) {
	//	    testLexer();
	//	}
}
