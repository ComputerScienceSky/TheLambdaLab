
public class Function implements Expression {
    private Expression exp;
    private Variable param;

    
    //im actually kindof proud of this file
    //like its really well organized
    //probably cause its like 20 lines but...
    
    public Function(Variable v, Expression e){
        exp = e;
        param = v;
        linkVars(e);
    }
    
    //links all variables to their parameters
    public void linkVars(Expression e) {
    	if(e instanceof Variable) {
    		if(e.toString().equals(param.toString())) {
    			((Variable)e).setParent(param);
    			((Variable)e).setID(param.getID());
    			
    		}
    	} else if(e instanceof Function) {
    		linkVars(((Function)e).getExp());
    	} else if(e instanceof Application) {
    		linkVars(((Application)e).getLeft());
    		linkVars(((Application)e).getRight());
    	}
    }
    
    public Function deepCopy() {
    	return new Function(param.paramCopy(), exp.deepCopy());
    }

    public Expression getExp(){
        return exp;
    }

    public Variable getVar(){
        return param;
    }

    public String toString(){
        return "(λ" + param + "." + exp + ")";
    }

}