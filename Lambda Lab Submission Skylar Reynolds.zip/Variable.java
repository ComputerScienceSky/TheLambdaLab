
public class Variable implements Expression {
	private String name;
	private Variable parent; 
	private int localID;
	private int parentID = 0;
	private boolean free = false;
	
	
	//there is def much simpler ways to do all of this
	//so dont jusge me too much
	//im aware that it is stupid
	//but it works
	//i will not change something that works
	public Variable(String name) {
		this.name = name;
		this.parent = null;
	}
	
	public Variable deepCopy() {
		Variable newVar = new Variable(name);
		newVar.setParentID(getParentID());
		if(free)
			newVar.setFree();
    	return newVar;//this;
    }
	
	public Variable paramCopy() {
		Variable newVar = new Variable(name);
		newVar.setID(localID);
		return newVar;
	}

	public Variable getParent(){
		return parent;
	}

	public void setParent(Variable v){
		if(parent == null) {
			if(parentID == 0 || parentID == v.getID()) {
				parent = v;
				parentID = v.getID();
			}
		}
	}

	public String getName(){
		return name;
	}
	
	public int getID() {
		return localID;
	}
	
	public void setID(int id) {
		localID = id;
	}
	
	public int getParentID() {
		return parentID;
	}
	
	public void setParentID(int id) {
		parentID = id;
	}

	public void setName(String s){
		if(!free)
			name = s;
	}
	
	public void setFree() {
		free = true;
	}
	
	public String toString() {
		return name;
	}
	
	public boolean isFree() {
		return free;
	}

}
