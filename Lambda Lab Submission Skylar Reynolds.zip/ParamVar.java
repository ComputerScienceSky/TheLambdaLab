
import java.util.ArrayList;

public class ParamVar extends Variable {

    ArrayList<BoundVar> arr = new ArrayList<BoundVar>();

    public ParamVar(String name){
        super(name);
    }

    public ParamVar(String name, ArrayList<BoundVar> list) {
        super(name);
        this.arr = list;
    }

    public void addVar(BoundVar var) {
        arr.add(var);
    }

    public void setName(String newName) {
        name = newName;
    }

    public ArrayList<BoundVar> getList() {
        return arr;
    }

    @Override
    public String toString() {
        return name;
    }
}