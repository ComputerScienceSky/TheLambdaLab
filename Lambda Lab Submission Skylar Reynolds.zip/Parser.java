import java.util.HashMap;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;

public class Parser {
	private ArrayList<String> tokens;
	private ArrayList<Byte> parens = new ArrayList<>();
	private HashMap<String, Expression> symbols = new HashMap<>();
	//following 2 are extra credit added
	private String s;
	private boolean changed;
	//end of extra credit added
	//dont ask me why i added them in the middle
	//i felt like it
	private ArrayList<Variable> previousVars = new ArrayList<>();
	private ArrayList<String> varNames = new ArrayList<>();
	private ArrayList<String> keys;
	private String firstToken = "";

	

	public Expression parse(ArrayList<String> tokenList) throws ParseException {
		tokens = tokenList;

		//if there is nothing it is a variable
		if(tokens.size() == 0){
			return new Variable("");
		}
		firstToken = tokens.get(0);
		//there is only a try statement here because it is in the starter code
		//and the computer yells at me without it
		//i just need u to know that i hate try catch statements
		//but stupid eclipse decided that i needed it
		//i hate eclipse
		try{
			//this is extra credit number 1
			Expression exp = recursion_parse(null);
			
			s = "";
			symbols.forEach((key, value) -> {
				if(exp.toString().equals(value.toString())) {
					s = key;
					changed = true;
				}
			});
			if(changed && !(s.toString().equals("")))
				return new Variable(s);
			
			return exp;
		}
		catch(Exception e){
			System.out.println("Incorrectly Formatted Expression. "+e);
		}
		//again eclipse yells at me FOR LITERALLY DOING NOTHIGN SO I NEED THIS STATEMENT
		//IT DOES NOTHIGN
		return null;
		
	}

	private Expression recursion_parse(Expression exp){
		//if 0 it is a variable once again
		if(tokens.size() == 0){
			return exp;
		}
		String s = tokens.get(0);
		//System.out.println(s);
		tokens = new ArrayList<String>(tokens.subList(1, tokens.size()));
		
		//this is the lambda sign do not forget
		//one slash does not work
		//its not eclipses fault though (this time)
		if(s.equals("\\")){
			//first thing after lambda is the main var
			Variable v = new Variable(tokens.get(0));
			//add to list of vars 
			previousVars.add(v);
			//new tokens list minus what i have parses
			tokens = new ArrayList<String>(tokens.subList(2, tokens.size())); 
			//if i have no parenthesis yet it means the lambda was all sad and lonely and not inside parenthesis
			if (parens.isEmpty()) {
				//if exp is lonely we have a lonely function :(
				if(exp == null) {
					return recursion_parse(new Function(v, recursion_parse(null))); 
				}
				//exp gets to be an application if it isnt lonely
				//i guess lonely expressions dont get to have left and right friends 
				return recursion_parse(new Application(exp, new Function(v, recursion_parse(null))));
			}
			else {
				//if our function is parethesized
				if(exp == null) {
					//it can still be lonely though :(
					//pretty much the same as before
					//parenthesis dont solve all of our problems
					return new Function(v, recursion_parse(null)); 
				}
				return new Application(exp, new Function(v, recursion_parse(null)));
			}
		}
		if(s.equals("(")){
			//i find all the parenthesis and then go normal again
			//no parenthesy left behind
			parens.add((byte)1);
			if(exp == null){
				Expression paren = recursion_parse(exp);
				return recursion_parse(paren);
			}
			Expression e = recursion_parse(null);
			//if it gets to this point it had to be an application
			return recursion_parse(new Application(exp, e)); 
		}
		if(s.equals(")")){
			//if you run into a ')', recurse back to where '(' was found 
			//so that my ')' parenthese doesnt get lonely without its buddy
			//unlike some expressions parenthessi always deserve a friend (i hate the y combinator)
			parens.remove(0);
			return exp;
		}
		if(s.equals("=")){
			//this stores values and relates a little back to extra credit number one
			//no idea why error, but it works so im not touching it
			keys = new ArrayList(symbols.keySet());
			Expression n = symbols.putIfAbsent(exp.toString(), recursion_parse(null));
			//basically like you cant do something twice
			//if 0 already exists as a value why are you trying to copy her???
			//get some originality
			if(n == null && !keys.contains(firstToken)){
				return new Variable("Added " + symbols.get(exp.toString()) + " as " + exp);
			}
			else{
				//yeah sstop trying to copy something that already exists
				//create something new
				//you have to innovate in the fashion industry
				return new Variable(firstToken + " is already defined");
			}
		}
		if(s.equals("run")){
			//my runner
			//these var names are lowkey kinda confusing ... but i am simply following the basic principle of coding
			//if it works don't touch it
			Expression runnable = recursion_parse(null);
			Expression ran = run(runnable);
			
			//why did i choose these names
			//i hate myself
			//WHY DID I DO THIS
			while(isSimplified(ran)) {
				ran = run(ran);
				
			}
			return ran;
		}
//		this literally should work but I get the stupidest error that Integer class doesnt exist????
//		literally WHTA
//		im just deleteing this idc
//		if (s.equals("populate")) {
//		}
		else{
			//otherwise, the token is a variable
			Expression mapped = symbols.get(s);

			if(mapped == null){
				if(exp == null)
					return recursion_parse(new Variable(s));
				return recursion_parse(new Application(exp, new Variable(s)));
			}
			if(exp == null)
				return recursion_parse(mapped);
			return recursion_parse(new Application(exp, mapped)); //later, check for s in stored expressions list
		}
	}
	private boolean isSimplified(Expression exp) {
		//the function name makes no sense for variables but i'm not changing it
		if(exp instanceof Variable) {
			return false;
		}
		if(exp instanceof Function) {
			return isSimplified(((Function)exp).getExp());
		}
		if(exp instanceof Application) {
			if(((Application)exp).getLeft() instanceof Function) {
				return true;
			}
			boolean left = isSimplified(((Application)exp).getLeft());
			boolean right = isSimplified(((Application)exp).getRight());
			return (left || right);
		}
		return false;
	}
	private Expression run(Expression exp){ //implements my BETA reductions
		if (exp instanceof Variable) {
			if(previousVars.contains(exp)) {
				((Variable)exp).setParentID(((Variable)exp).getParentID() + 1);
			}
			return exp;
		}
		if (exp instanceof Function){
//			if (symbols.containsValue(exp)) {
//				return symbols.get(exp);
//			}
		    Function func = (Function) exp;
		    Variable var = func.getVar();
		    Expression funcExp = func.getExp();
		    Expression newExp = run(funcExp);
		    if (newExp instanceof Variable) {
		    	if (((Variable) newExp).equals(var) && ((Variable) newExp).getParentID() == 0) {
		            return newExp; // Do not perform replacement if the function variable is unchanged
		        }
		    }
		    return new Function(var, newExp);
		}
		
		Expression left = run(((Application)exp).getLeft());
		Expression right = run(((Application)exp).getRight());
		Expression newApp = new Application(left, right);


		if(left instanceof Function){
			ArrayList<String> oldNames = new ArrayList<>();
			ArrayList<Variable> oldVars = new ArrayList<>();
			getVarNames(right, oldNames, oldVars);
			Variable var = ((Function)left).getVar();
			Expression funcExp = ((Function)left).getExp();
			newApp = varReplace(var, funcExp, right);
			if(newApp instanceof Application) {
				return run(newApp);
			}
		}

		return newApp;
	}
	private Expression varReplace(Variable v, Expression e, Expression replace) {
	    if (e instanceof Variable) {
	        Variable var = (Variable) e;
	        if (var.getParent() == v && !var.isFree()) {
	            return replace.deepCopy(); // Perform a deep copy of the replacement expression
	        }
	        return e;
	    }
	    if (e instanceof Application) {
	        Application app = (Application) e;
	        Expression left = varReplace(v, app.getLeft(), replace);
	        Expression right = varReplace(v, app.getRight(), replace);
	        return new Application(left, right);
	    }
	    if (e instanceof Function) {
	    	 Function func = (Function) e;
	         Variable var = func.getVar();
	         if (var.equals(v)) {
	             return e; // Do not perform replacement if the function variable matches the target variable
	         }
	         Expression exp = varReplace(v, func.getExp(), replace);
	         return new Function(var, exp);
	    }
	    return e;
	}

	private void getVarNames(Expression e, ArrayList<String> varNames, ArrayList<Variable> expList){

		
//		if(e instanceof Variable && ((Variable)e).getParent() == null && ((Variable)e).getParentID() == 0){
//			nameList.add(e.toString());
//			expList.add((Variable)e);
//			((Variable)e).setFree();
//		}
//		if(e instanceof Application){
//			getVarNames(((Application)e).getLeft(), nameList, expList);
//			getVarNames(((Application)e).getRight(), nameList, expList);
//		}
//		if(e instanceof Function){
//			getVarNames(((Function)e).getExp(), nameList, expList);
	}
	
//	private void identifyFree(ArrayList<String> varNames) {
//		
//	}


	private void changeBoundVar(ArrayList<String> nameList, ArrayList<Variable> expList){
		
//		for(int i = 0; i < nameList.size(); i++){
//			expList.get(i).setName(nameList.get(i));
//		}

	}
	
	private void alphaReductionsApply(Expression exp) {
		if(exp instanceof Function) {
			alphaReductionsApply(((Function)exp).getExp());
		}
		if(exp instanceof Application) {
			alphaReductionsApply(((Application)exp).getLeft());
			alphaReductionsApply(((Application)exp).getRight());
		}
	}

	//alpha reductions
	//private void alphaReductions(Expression e){
	//	  getNames method
	//	  check for a parent to determine boundness
	//	  take free variables and check if any bound variables have the same name
	//    change bound variables to be varName + 1
	//	  call method for changing boudn varName
	//}
}




//	public Expression parse(ArrayList<String> tokens) throws ParseException {
//		if(tokens.size() == 1) {
//			Variable var = new Variable(tokens.get(0));
//			return var;
//		} else {
//			int[] depth = depthMap(tokens);
//			ArrayList<String> parenLevel = new ArrayList<>();
//			
//			for(int i = 0; i < depth.length; i++) {
//				if(depth[i] == 0) {
//					ArrayList<String> left = new ArrayList<>();
//					left.add(tokens.remove(0));
//					Application app = new Application(parse(left), parse(tokens));
//					return app;
//				} else if(i != 0 && depth[i] == depth[i - 1]) {
//					parenLevel.add(tokens.get(i));
//				} else if(i != 0 && depth[i] > depth[i - 1]) {
//					if(parenLevel.size() > 0) {
//						ArrayList<String> left = parenLevel;
//						left.add(tokens.remove(0));
//						Application app = new Application(parse(left), parse(tokens));
//						return app;
//					} else {
//						parenLevel.add(tokens.get(i));
//					}
//				}
//				
//			}
//			
//		}
//		throw new ParseException("issue", 0);
//	}
//	private int[] depthMap(ArrayList<String> tokens) {
//		int[] depthMap = new int[tokens.size()];
//		int parenLevel = 0;
//		
//		for(int i = 0; i < tokens.size(); i++) {
//			depthMap[i] = parenLevel;
//			if(tokens.get(i).equals("(")){
//				parenLevel += 1;
//			} else if (tokens.get(i).equals(")")){
//				parenLevel -= 1;
//			}
//		}
//		
//		return depthMap;
//		
//	}
//	public ArrayList<String> preParse(ArrayList<String> tokens) {
//		ArrayList<String> preParseTokens = new ArrayList<>();
//		boolean inLambda = false;
//		for (String token : tokens) {
//			if (token.equals("\\") || token.equals("λ")) {
//				inLambda = true;
//				token = "(" + token;
//			} else if (inLambda && !token.equals(".")) {
//				if (token.equals(")")) {
//					token = token + ")";
//					inLambda = false;
//				}
//			}
//			
//			preParseTokens.add(token);
//		}
//		
//		System.out.println(preParseTokens);
//		return preParseTokens;
//	}
//}
